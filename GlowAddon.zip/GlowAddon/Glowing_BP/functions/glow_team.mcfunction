execute @p[tag=glow_set] ~~~ tag @a add glow_set
execute @p[tag=!glow_set] ~~~ scoreboard objectives add glow_p dummy
execute @p[tag=!glow_set] ~~~ scoreboard objectives add glow_rule dummy
execute @p[tag=!glow_set] ~~~ scoreboard objectives add glow dummy
execute @p[tag=!glow_set] ~~~ tag @a add glow_set

event entity @a property_set